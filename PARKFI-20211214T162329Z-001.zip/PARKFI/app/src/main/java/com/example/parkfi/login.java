package com.example.parkfi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class login extends AppCompatActivity {
    private Button button2;
    TextView dtextview;
    TextView etextview;
    TextView ftextview;
    ImageView cimageview;
    ImageView dimageview;
    Button abutton;
    Button bbutton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        dtextview = findViewById(R.id.textview1);
        etextview = findViewById(R.id.textView2);
        ftextview = findViewById(R.id.textView3);
        cimageview = findViewById(R.id.imageView2);
        dimageview = findViewById(R.id.imageView8);
        abutton = findViewById(R.id.button);
        bbutton = findViewById(R.id.button2);
        bbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openMapActivity();
            }
        });
    }
    public void openMapActivity() {
        Intent intent = new Intent(this, mapActivity.class);
        startActivity(intent);

    }
}